<?php
/*
Template Name: Games for Kids
 */

get_header();?>

<section>
	<div class="container pad0all">
		<img src="http://tenderminds.live/wp-content/uploads/2021/08/games-blue.jpg" class="h600px" alt="Homepage banner" width="100%">
		<!--<div class="row">
			<div class="col-12 col-sm-12 col-md-12 col-lg-12" style="height: 700px;background: black;">
				<p style="color:white; font-weight:700" class="aven-book">BANNER</p>
			</div>
		</div>-->
		<p class="centertext fs30mobile">Play your favourite Games!</p>
	</div>
</section>

<section class="bggradient padt3b10 whitebackmobile">
<section>
	<div class="container">
		<p class="pforvideos wow fadeInLeft fs20mobile"><u>ENJOY YOU FAVOURITE GAMES AND QUIZZES</u></p>
	</div>
</section>

<section>
	<div class="container">
		<div class="row gamesrow">
			<div class="col-12 col-sm-12 col-md-4 col-lg-4 ptpb15mob dhideformobile">
			    <div class="tcenter">
					<!-- Button trigger modal -->
					<button type="button" class="btn btn-primary forbuttondesign buttonquiz wow pulse w90h150mobile" data-toggle="modal" data-target="#exampleModal">
					  FIND ANIMALS AND BIRDS
					</button>

					<!-- Modal -->
					<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
					  <div class="modal-dialog" role="document">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title" id="exampleModalLabel">FIND ALL THE ANIMALS AND BIRDS</h5>
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div class="modal-body">
					        <?php echo do_shortcode('[game-wordsearch id="202" ]'); ?>
					      </div>
					      
					    </div>
					  </div>
					</div>
				</div>
			</div>
			<div class="col-12 col-sm-12 col-md-4 col-lg-4 ptpb15mob">
				<div class="tcenter">
					<!-- Button trigger modal -->
					<button type="button" class="btn btn-primary forbuttondesign buttonquiz wow pulse w90h150mobile" data-toggle="modal" data-target="#exampleModal2">
					  TAKE ANIMAL QUIZ
					</button>

					<!-- Modal -->
					<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel2" aria-hidden="true">
					  <div class="modal-dialog" role="document">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title" id="exampleModalLabel2">QUIZ ON ANIMALS AND BIRDS</h5>
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div class="modal-body">
					        <?php echo do_shortcode('[quiz-cat id="219"]'); ?>
					      </div>
					      <!--<div class="modal-footer">
					        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					        <button type="button" class="btn btn-primary">Save changes</button>
					      </div>-->
					    </div>
					  </div>
					</div>
				</div>
			</div>
			<div class="col-12 col-sm-12 col-md-4 col-lg-4 ptpb15mob">
				<div class="tcenter">
					<!-- Button trigger modal -->
					<button type="button" class="btn btn-primary forbuttondesign buttonquiz wow pulse w90h150mobile" data-toggle="modal" data-target="#exampleModal5">
					  PLAY EQUATION GAME
					</button>

					<!-- Modal -->
					<div class="modal fade" id="exampleModal5" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel5" aria-hidden="true">
					  <div class="modal-dialog" role="document">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title" id="exampleModalLabel5">PLAY EQUATION GAME</h5>
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div class="modal-body">
					        <?php echo do_shortcode('[funny_equations]'); ?>
					      </div>
					      <!--<div class="modal-footer">
					        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					        <button type="button" class="btn btn-primary">Save changes</button>
					      </div>-->
					    </div>
					  </div>
					</div>
				</div>
			</div>
			
		</div>
	</div>
	
</section>
</section>

<section class="ptb2 mazebackground dhideformobile">
<section>
	<div class="container">
		<p class="pforvideos wow fadeInLeft fs20mobile"><u>PLAY THE SNAKE GAME</u></p>
	</div>
</section>

<section class="mozcenter pb3">
	<?php echo do_shortcode('[snake]'); ?>      
</section>
</section>

<section class="ptb2 bggradient">
<section>
	<div class="container">
		<p class="pforvideos wow fadeInLeft fs20mobile"><u>PLAY THE DINOSAUR GAME</u></p>
	</div>
</section>

<section class="mozcenter pb3 dinopad">
	<?php echo do_shortcode('[dinosaur-game]'); ?>
</section>
</section>

<section class="ptb2 mazebackground">
<section>
	<div class="container">
		<p class="pforvideos wow fadeInLeft fs20mobile"><u>PLAY THE MANIACAL MAZE GAME</u></p>
	</div>
</section>
</section>

<section class="mozcenter pb3">
	<?php echo do_shortcode('[maniacal_maze]'); ?>
</section>
   
</div>
</div>
</div>
<?php get_footer();