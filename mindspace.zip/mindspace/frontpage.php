<?php
/*
Template Name: Home Page
 */

get_header();?>
<section>
	<div class="container pad0all">
		<img src="http://tenderminds.live/wp-content/uploads/2021/08/home-blue2.jpg" class="h600px" alt="Homepage banner" width="100%">
		<!--<div class="row">
			<div class="col-12 col-sm-12 col-md-6 col-lg-6" style="height: 700px; background: black;">
				<p style="color:white; font-weight:700" class="aven-book">SECTION 1</p>
			</div>
			<div class="col-12 col-sm-12 col-md-6 col-lg-6" style="background: red;">
				<p style="color:white; font-weight:700" class="aven-book">SECTION 2</p>
			</div>
		</div>-->
		<p class="centertext fs30mobile">Welcome to TenderMinds!</p>
	</div>
</section>
<section class="homevideospad">
	<div class="container">
		<p class="pforvideos wow fadeInLeft"><u>What is Mental Health?</u></p>
		<div class="row">
			<div class="col-12 col-sm-12 col-md-2 col-lg-2"></div>
			<div class="col-12 col-sm-12 col-md-8 col-lg-8">
				<iframe class="h190pxmobile" width="100%" height="370" src="https://www.youtube.com/embed/nCrjevx3-Js" title="Mental Health" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			</div>
			<div class="col-12 col-sm-12 col-md-2 col-lg-2"></div>
		</div>
	</div>
</section>
<section class="homevideospad bggradient">
	<div class="container">
		<p class="pforvideos wow fadeInLeft"><u>How can we be Healthy?</u></p>
		<div class="row">
			<div class="col-12 col-sm-12 col-md-2 col-lg-2"></div>
			<div class="col-12 col-sm-12 col-md-8 col-lg-8">
				<iframe class="h190pxmobile" width="100%" height="370" src="https://www.youtube.com/embed/dhpCdqOtuj0" title="Mental Health" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			</div>
			<div class="col-12 col-sm-12 col-md-2 col-lg-2"></div>
		</div>
	</div>
</section>
<section class="homevideospad">
	<div class="container">
		<p class="pforvideos wow fadeInLeft"><u>Why is it important to talk about your Feelings?</u></p>
		<div class="row">
			<div class="col-12 col-sm-12 col-md-2 col-lg-2"></div>
			<div class="col-12 col-sm-12 col-md-8 col-lg-8">
				<p class="montfont fs14mobile">
				    How many feelings can you name? Happy, sad, scared? 
				    That's a good start.
				</p>
				<p class="montfont fs14mobile">
				    Can you name some more? How about playful, joyful, calm? 
				    Mad, upset, worried. Confused, lonely, nervous. Grateful, glad, cozy. Loved, friendly, peaceful.
				</p>
				<p class="montfont fs14mobile">
				    There are so many feelings to name. Try coming up with some of your own.
				</p>
				<p class="montfont fs14mobile">
				    No matter how you feel — good or bad — it's healthy to put your feelings into words. Talking about feelings helps us feel close to people who care. It helps us feel better when we're sad or scared.
				</p>
				<p class="montfont fs14mobile">
				    Putting feelings into words helps us use self-control when we feel mad or upset. If your little brother took something of yours, you can say, "Hey, I'm annoyed that you took that without asking me. Next time, please ask." No need to get in a big fight over it. Just say how you feel and why, without yelling.
				</p>
				<h4 class="montfont fweight700 wow fadeInLeft fs18mobile">
				    <u>Know Your Feelings</u>
				</h4>
				<p class="montfont fs14mobile">
				    It's easier to talk about your feelings if you know how you feel and why. Try these easy steps:
				</p>
				<p class="montfont fs14mobile">
				    <li class="montfont fs14mobile">
				        <ol class="montfont fs14mobile">Think of the name for how you feel. (Let's say you feel nervous.)</ol>
				        </li class="montfont fs14mobile">
				        <li class="montfont fs14mobile">
				        <ol class="montfont fs14mobile">Think of why you feel that way. (Let's say you are nervous because you have a spelling test tomorrow.)</ol>
				        </li>
				        <li class="montfont fs14mobile">
				        <ol class="montfont fs14mobile">Put them together into words. (Say to yourself, "I feel nervous about my spelling test tomorrow.")</ol>
				    </li>
				</p>
				<p class="montfont fs14mobile">
				    If you don't know why you feel a certain way, you can still talk about it. You can say, "I feel upset, but I don't know why."
				    </p>
				    <h4 class="montfont fweight700 wow fadeInLeft fs18mobile">
				        <u>Pick Someone to Talk to</u>
				    </h4>
				    <p class="montfont fs14mobile">
				        A parent, grandparent, or a friend can be a good person to talk to. It's easier than you think. You can start by going to the person and saying, "Can we talk for a minute?" Then say how you feel and why.
				    </p>
				    <p class="montfont fs14mobile">
				        Let the other person listen. Maybe they will give you advice. Or say something kind. Maybe they will help you laugh, or give you a hug. Or say, "Don't worry, I'll help you study your spelling words." Just saying how you feel and why helps you start to feel better. It helps to know you are not alone with a problem or worry.
				    </p>
				    <h4 class="montfont fweight700 wow fadeInLeft fs18mobile">
				        <u>Talk About Feelings Any Time</u>
				    </h4>
				    <p class="montfont fs14mobile">
				        You don't have to wait for a big problem to talk about your feelings. You can say how you feel any time. It's a good thing to practice.
				    </p>
				    <p class="montfont fs14mobile">
				        Talking about feelings doesn't have to be a big talk. You can make a short and simple comment. Like this:
				    </p>
				    <p class="montfont fs14mobile">
				        <li class="montfont fs14mobile">
				        <ol class="montfont fs14mobile">"Dad, I'm really glad we're having pizza tonight! Thanks!"</ol>
				        </li>
				        <li class="montfont fs14mobile">
				        <ol class="montfont fs14mobile">"I'm excited about the game tonight. I think the coach will let me start."</ol>
				        </li>
				        <li class="montfont fs14mobile">
				        <ol class="montfont fs14mobile">"I'm so relieved because I did really well on my math test!"</ol>
				        <li class="montfont fs14mobile">
				        <ol class="montfont fs14mobile">"I felt so awkward when I asked Kyle to the dance, and I was so happy when he said yes!"</ol>
				        </li>
				    </li>
				    </p>
				    <p class="montfont fs14mobile">
				        You don't have to talk about every feeling you have. But noticing your feelings and saying how you feel and why is good practice. The more you do it, the easier it gets. Talking about your feelings is a healthy way to express them. And when you have difficult feelings you need to talk over, you'll be ready.
				    </p>
			</div>
			<div class="col-12 col-sm-12 col-md-2 col-lg-2"></div>
		</div>
	</div>
</section>

   
</div>
</div>
</div>
<?php get_footer();