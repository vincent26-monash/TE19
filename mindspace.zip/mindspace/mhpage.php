<?php
/*
Template Name: What is Mental Health?
 */

get_header();?>

<section>
	<div class="container pad0all">
		<img src="http://tenderminds.live/wp-content/uploads/2021/08/parents-orange.jpg" class="h600px" alt="Homepage banner" width="100%">
		<!--<div class="row">
			<div class="col-12 col-sm-12 col-md-12 col-lg-12" style="height: 700px;background: black;">
				<p style="color:white; font-weight:700" class="aven-book">BANNER</p>
			</div>
		</div>-->
		<p class="centertextorange tacenter fs30mobile">Are you worried about your child's Mental Health?</p>
	</div>
</section>
   
</div>
</div>
</div>
<?php get_footer();