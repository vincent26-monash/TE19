<?php
/*
Template Name: Videos for kids
 */

get_header();?>

<section>
	<div class="container pad0all">
		<img src="http://tenderminds.live/wp-content/uploads/2021/08/home-orange.jpg" class="h600px" alt="Homepage banner" width="100%">
		<!--<div class="row">
			<div class="col-12 col-sm-12 col-md-12 col-lg-12" style="height: 700px;background: black;">
				<p style="color:white; font-weight:700" class="aven-book">BANNER</p>
			</div>
		</div>-->
		<p class="centertextorange fs30mobile">Watch your favourite Videos!</p>
	</div>
</section>

<section>
	<div class="container">
		<p class="pforvideos wow fadeInLeft fs20mobile"><u>WATCH YOUR FAVOURITE VIDEOS</u></p>
	</div>
</section>

<section>
<div class="content mb50mobile">
  
  <div class="video-gallery">
    
    <div class="gallery-item ">
     <img src="http://tenderminds.live/wp-content/uploads/2021/08/pexels-robert-anthony-carbone-598966-2-scaled.jpg" alt="Animals"/>
      <div class="gallery-item-caption">
        <!--<div>-->
          <h2 class="fs25mobile">Animals</h2>
          <p>Watch Videos Of Your Favourite Animals!</p>
        <!--</div>-->
        <a href="https://www.youtube.com/watch?v=_62pkcpLZqM"></a>
      </div>
      <div class="gallery-item-caption1">
        <a href="https://www.youtube.com/watch?v=7CLzKCuvDe0"></a>
      </div>
      <div class="gallery-item-caption2">
        <a href="https://www.youtube.com/watch?v=CKZJ1jGehoU"></a>
      </div>
    </div>

    <div class="gallery-item">
      <img src="http://tenderminds.live/wp-content/uploads/2021/08/pexels-couleur-2317904-1-scaled.jpg" alt="Birds"/>
      <div class="gallery-item-caption">
        <!--<div>-->
          <h2 class="fs25mobile">Birds</h2>
          <p>Watch Videos Of Your Favourite Birds!</p>
        <!--</div>-->
        <a href="https://www.youtube.com/watch?v=CTcoCHKnkT8"></a>
      </div>
       <div class="gallery-item-caption1">
        <a href="https://www.youtube.com/watch?v=NxJ_EvPtC-o"></a>
      </div>
      <div class="gallery-item-caption2">
        <a href="https://www.youtube.com/watch?v=CyBB9agMAKA"></a>
      </div>
    </div>
    
    <div class="gallery-item">
     <img src="http://tenderminds.live/wp-content/uploads/2021/08/pexels-samarth-singhai-1145274-1-scaled.jpg" class="Aqua" alt="North Cascades National Park"/>
      <div class="gallery-item-caption">
        <!--<div>-->
          <h2 class="fs25mobile">Sea Creatures</h2>
          <p>Watch Videos Of Your Favourite Aquatic Creatures!</p>
        <!--</div>-->
        <a href="https://www.youtube.com/watch?v=nvq_lvC1MRY"></a>
      </div>
      <div class="gallery-item-caption1">
        <a href="https://www.youtube.com/watch?v=6O8eZuMmlwk"></a>
      </div>
      <div class="gallery-item-caption2">
        <a href="https://www.youtube.com/watch?v=vQoR7gJTirk"></a>
      </div>
    </div>

    <div class="gallery-item">
      <img src="http://tenderminds.live/wp-content/uploads/2021/08/pexels-neil-yonamine-7963004.jpg" alt="Space"/>
      <div class="gallery-item-caption">
        <!--<div>-->
          <h2 class="fs25mobile">Space</h2>
          <p>Watch Videos Of Planets And Solar System!</p>
        <!--</div>-->
        <a href="https://www.youtube.com/watch?v=aOuVTGG9Bik"></a>
      </div>
      <div class="gallery-item-caption1">
        <a href="https://www.youtube.com/watch?v=uTxnECbI0-U"></a>
      </div>
      <div class="gallery-item-caption2">
        <a href="https://www.youtube.com/watch?v=Un5SEJ8MyPc"></a>
      </div>
    </div>

    <div class="gallery-item">
      <img src="http://tenderminds.live/wp-content/uploads/2021/08/pexels-lisa-1083822-1-scaled.jpg" alt="Flora"/>
      <div class="gallery-item-caption">
        <!--<div>-->
          <h2 class="fs25mobile">Flora</h2>
          <p>Watch Videos Of Flowers!</p>
        <!--</div>-->
        <a href="https://www.youtube.com/watch?v=StPwbyWOpbQ"></a>
      </div>
      <div class="gallery-item-caption1">
        <a href="https://www.youtube.com/watch?v=i810CxN5Q6Q"></a>
      </div>
      <div class="gallery-item-caption2">
        <a href="https://www.youtube.com/watch?v=64RVjUU5bxw"></a>
      </div>
    </div>

    <div class="gallery-item">
      <img src="http://tenderminds.live/wp-content/uploads/2021/08/charlie-solorzano-RQ9F_GNh0ww-unsplash-1-scaled.jpg" alt="Craft"/>
      <div class="gallery-item-caption">
        <!--<div>-->
          <h2 class="fs25mobile">Simple Craft</h2>
          <p>Watch Videos For Simple 5 Minute Craft!</p>
        <!--</div>-->
        <a href="https://www.youtube.com/watch?v=A-DowvVUizw"></a>
      </div>
      <div class="gallery-item-caption1">
        <a href="https://www.youtube.com/watch?v=sT-fdlxELxs"></a>
      </div>
      <div class="gallery-item-caption2">
        <a href="https://www.youtube.com/watch?v=fjvyAPUnNtA"></a>
      </div>
    </div>

  </div>
</div>
</section>

<!--<section>
<div id="accordion">
  <div class="card">
    <div class="card-header backorange" id="headingOne">
      <h5 class="mb-0">
        <button class="btn btn-link aven-book buttonaccordion wow pulse" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          CLICK TO WATCH PEPPA PIG EPISODES!
        </button>
      </h5>
    </div>

    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
      <div class="card-body">
	        <div id="carouselExampleControls1" class="carousel slide" data-ride="carousel" data-interval="false">

	        	<div class="row">
	        		<div class="col-12 col-sm-12 col-md-1 col-lg-1">
	        			<a class="carousel-control-prev" href="#carouselExampleControls1" role="button" data-slide="prev">
				    	<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				    	<span class="sr-only">Previous</span></a>
	        		</div>
	        		<div class="col-12 col-sm-12 col-md-10 col-lg-10"> 

						<div class="carousel-inner">
						    <div class="carousel-item active">
						      	<div class="row ptb25">
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/eGb3Edtrm1s" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/hWdLhB2okqA" frameborder="0" allowfullscreen></iframe>
						        	</div>

						        </div>
						        <div class="row ptb25">
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/Sqp0VRyLjBA" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	<div class="col-12 col-sm-12 col-md-4 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/Ez0qR3m1G4g" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	
						        </div>
						    </div>
						    <div class="carousel-item">
						     	<div class="row ptb25">
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/6xJhCJI5Ixw" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	<div class="col-12 col-sm-12 col-md-4 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/EPr58OmU0-8" frameborder="0" allowfullscreen></iframe>
						        	</div>

						        </div>
						        <div class="row ptb25">
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/tPnd2CgP7To" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	<div class="col-12 col-sm-12 col-md-4 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/-KiG04TexiY" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	
						        </div>
						    </div>
						    
						</div>

					</div>
				<div class="col-12 col-sm-1 col-md-1 col-lg-1">
					<a class="carousel-control-next" href="#carouselExampleControls1" role="button" data-slide="next">
				    	<span class="carousel-control-next-icon" aria-hidden="true"></span>
				    	<span class="sr-only">Next</span></a>
				</div>
				</div> 
				  
			</div>
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header backorange" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed aven-book buttonaccordion wow pulse" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          CLICK TO WATCH PAW PATROL EPISODES!
        </button>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body">
	        <div id="carouselExampleControls2" class="carousel slide" data-ride="carousel" data-interval="false">

	        	<div class="row">
	        		<div class="col-12 col-sm-12 col-md-1 col-lg-1">
	        			<a class="carousel-control-prev" href="#carouselExampleControls2" role="button" data-slide="prev">
				    	<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				    	<span class="sr-only">Previous</span></a>
	        		</div>
	        		<div class="col-12 col-sm-12 col-md-10 col-lg-10"> 

						<div class="carousel-inner">
						    <div class="carousel-item active">
						      	<div class="row ptb25">
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/besZrfeEKpc" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/xpMqhjZQvgY" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	
						        </div>
						        <div class="row ptb25">
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/-CuyXQQElQU" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/kr7uE1YVKd0" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	
						        </div>
						    </div>
						    <div class="carousel-item">
						     	<div class="row ptb25">
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/2hcnV0rPong" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/1SQI_kJyPD8" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	
						        </div>
						        <div class="row ptb25">
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/B9lEjSSrvZk" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/DcChrghcWL4" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	
						        </div>
						    </div>
						    
						</div>

					</div>
				<div class="col-12 col-sm-1 col-md-1 col-lg-1">
					<a class="carousel-control-next" href="#carouselExampleControls2" role="button" data-slide="next">
				    	<span class="carousel-control-next-icon" aria-hidden="true"></span>
				    	<span class="sr-only">Next</span></a>
				</div>
				</div> 
				  
			</div>
      </div>
    </div>
</div>
  <div class="card">
    <div class="card-header backorange" id="headingThree">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed aven-book buttonaccordion wow pulse" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          CLICK TO WATCH GO JETTERS EPISODES!
        </button>
      </h5>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
      <div class="card-body">
	        <div id="carouselExampleControls3" class="carousel slide" data-ride="carousel" data-interval="false">

	        	<div class="row">
	        		<div class="col-12 col-sm-12 col-md-1 col-lg-1">
	        			<a class="carousel-control-prev" href="#carouselExampleControls3" role="button" data-slide="prev">
				    	<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				    	<span class="sr-only">Previous</span></a>
	        		</div>
	        		<div class="col-12 col-sm-12 col-md-10 col-lg-10"> 

						<div class="carousel-inner">
						    <div class="carousel-item active">
						      	<div class="row ptb25">
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/xlbwj6apsDc" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/E0SYdjw5iz0" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	
						        </div>
						        <div class="row ptb25">
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/8bRBjC4C51s" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/qDuutBzWBwU" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	
						        </div>
						    </div>
						    <div class="carousel-item">
						     	<div class="row ptb25">
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/vRU3o9ozAmc" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/FZ4M6VC77XA" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	
						        </div>
						        <div class="row ptb25">
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/6m1o2GLOSpY" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	<div class="col-12 col-sm-12 col-md-6 col-lg-6">
						        		<iframe id="video" width="100%" height="315" src="https://www.youtube.com/embed/Iq26DhzwaqA" frameborder="0" allowfullscreen></iframe>
						        	</div>
						        	
						        </div>
						    </div>
						    
						</div>

					</div>
				<div class="col-12 col-sm-1 col-md-1 col-lg-1">
					<a class="carousel-control-next" href="#carouselExampleControls3" role="button" data-slide="next">
				    	<span class="carousel-control-next-icon" aria-hidden="true"></span>
				    	<span class="sr-only">Next</span></a>
				</div>
				</div> 
				  
			</div>
      </div>
    </div>
  </div>
</div>
</section>-->

   
</div>
</div>
</div>
<?php get_footer();