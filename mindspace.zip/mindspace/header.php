<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package mindspace
 */

?>
<!doctype html>
<html <?php language_attributes(); ?> class="mtop0">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="icon" href="http://tenderminds.live/wp-content/uploads/2021/08/TenderMinds-favicon.png" type="image/x-icon"/>
    <link rel="shortcut icon" href="http://tenderminds.live/wp-content/uploads/2021/08/TenderMinds-favicon.png" type="image/x-icon"/>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Varela+Round&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Ultra&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Righteous&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">

	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	<div class="container-fluid">
		<div class="row">	
			<div class="col-12 col-md-2 paddleftandright0 fixedleftmenu pbot10mobile">
				<p class="text-center nomarginmobile">
					<a href = "http://tenderminds.live/"><img alt="" class="leftinmobile w60 ptop5 w20mobile ptop1pmobile" src="http://tenderminds.live/wp-content/uploads/2021/08/TenderMindsLogo-new.png" /></a>
					<a href="javascript:void(0)" class="d-inline-block d-sm-inline-block d-md-none d-lg-none mobile-nav-toggle rightinmobile ptbw17mobile ptop15mobile"><img alt="" src="http://tenderminds.live/wp-content/uploads/2021/08/hamorange.png"/></a>
				</p>
				<header id="masthead" class="site-header">
					<nav id="site-navigation" class="main-navigation">
					<?php
					wp_nav_menu( array(
					'theme_location' => 'menu-1',
					'menu_id'        => 'primary-menu',
					'menu_class'     => 'padfornavi main-menu',
					) );
					?>
					</nav>
				</header>
			</div>
			<div class="col-12 col-md-10 paddleftandright0 offset-md-2">
	<div id="content" class="site-content">
